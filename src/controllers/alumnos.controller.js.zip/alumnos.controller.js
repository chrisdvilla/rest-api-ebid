import { pool } from "../db.js";

export const getAlumnos = async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM alumno");
    res.json(rows);
  } catch (error) {
    return res.status(500).json({
      message: "Algo salio mal",
    });
  }
};

export const getAlumno = async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM alumno WHERE id = ?", [
      req.params.id,
    ]);

    if (rows.length <= 0)
      return res.status(404).json({
        message: "Alumno no encontrado",
      });

    res.json(rows[0]);
  } catch (error) {
    return res.status(500).json({
      message: "Algo salio mal",
    });
  }
};

export const createAlumno = async (req, res) => {
  const { foto, nombre,
        apellido_paterno,
        apellido_materno,
        ci, expedido,
        fecha_nacimiento,
        fecha_registro,
        lugar_nacimiento,
        direccion,
        telefono,
        email,
        num_registro,
        edad,
        genero,
        modalidad,
        anio_admision,
        estado,
        gestion,
        contacto,
        carrera
       } = req.body;
  console.log(req.body)

  const isoDate_fecha_registro = new Date(fecha_registro);
  const mySQLDateString_fecha_registro = isoDate_fecha_registro.toJSON().slice(0, 19).replace('T', ' ');

  const isoDate_fecha_nacimiento = new Date(fecha_nacimiento);
  const mySQLDateString_fecha_nacimiento = isoDate_fecha_nacimiento.toJSON().slice(0, 19).replace('T', ' ');
  
 
  try { 
      const [rows] = await pool.query(
      "INSERT INTO alumno (foto, nombre, apellido_paterno ,apellido_materno, ci, expedido, fecha_nacimiento, fecha_registro, lugar_nacimiento, direccion, telefono, email, num_registro, edad, genero, modalidad, anio_admision, estado, gestion, contacto, carrera) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?)",
      [foto, nombre, apellido_paterno ,apellido_materno, ci, expedido, mySQLDateString_fecha_nacimiento, mySQLDateString_fecha_registro, lugar_nacimiento, direccion, telefono, email, num_registro, edad, genero, modalidad, anio_admision, estado, gestion, contacto, carrera]
    ); 

    res.send({
      id: rows.insertId,
      nombre,
      apellido_paterno,
      apellido_materno,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Algo salio mal",
    });
  }
};

export const updateAlumno = async (req, res) => {
  const { id } = req.params;
  const { foto, nombre, apellido_paterno ,apellido_materno, ci, expedido, fecha_nacimiento, fecha_registro, lugar_nacimiento, direccion, telefono, email, num_registro, edad, genero, modalidad, anio_admision, estado, gestion, contacto, carrera } = req.body;
  console.log(req.body)
  const isoDate_fecha_registro = new Date(fecha_registro);
  const mySQLDateString_fecha_registro = isoDate_fecha_registro.toJSON().slice(0, 19).replace('T', ' ');

  const isoDate_fecha_nacimiento = new Date(fecha_nacimiento);
  const mySQLDateString_fecha_nacimiento = isoDate_fecha_nacimiento.toJSON().slice(0, 19).replace('T', ' '); 

  try {
    const [result] = await pool.query(
      "UPDATE alumno SET foto = IFNULL(?,foto), nombre = IFNULL(?,nombre), apellido_paterno = IFNULL(?,apellido_paterno), apellido_materno = IFNULL(?,apellido_materno), ci = IFNULL(?,ci), expedido = IFNULL(?,expedido), fecha_nacimiento = IFNULL(?,fecha_nacimiento), fecha_registro = IFNULL(?,fecha_registro), lugar_nacimiento = IFNULL(?,lugar_nacimiento), direccion = IFNULL(?,direccion), telefono = IFNULL(?,telefono), email = IFNULL(?,email), num_registro = IFNULL(?,num_registro), edad = IFNULL(?,edad), genero = IFNULL(?,genero), modalidad = IFNULL(?,modalidad), anio_admision = IFNULL(?,anio_admision), estado = IFNULL(?,estado), gestion = IFNULL(?,gestion), contacto = IFNULL(?,contacto), carrera = IFNULL(?,carrera) WHERE id = ?",
      [foto, nombre, apellido_paterno ,apellido_materno, ci, expedido, mySQLDateString_fecha_nacimiento, mySQLDateString_fecha_registro, lugar_nacimiento, direccion, telefono, email, num_registro, edad, genero, modalidad, anio_admision, estado, gestion, contacto, carrera, id]
    ); 

    if (result.affectedRows === 0)
      return res.status(404).json({
        message: "Alumno no encontrado",
      });

    const [rows] = await pool.query("SELECT * FROM alumno WHERE id= ?", [id]);

    res.json(rows[0]);
  } catch (error) {
    return res.status(500).json({
      message: "Algo salio mal",
    });
  }
};

export const deleteAlumno = async (req, res) => {
  try {
    const [result] = await pool.query("DELETE FROM alumno WHERE id = ?", [
      req.params.id,
    ]);

    if (result.affectedRows <= 0)
      return res.status(404).json({
        message: "Alumno no encontrado",
      });

    res.sendStatus(204);
  } catch (error) {
    return res.status(500).json({
      message: "Algo salio mal",
    });
  }
};
